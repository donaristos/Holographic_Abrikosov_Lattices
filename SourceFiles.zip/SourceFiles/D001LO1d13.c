
elem[12]+=
0
;
