
elem[92]+=
0
;
