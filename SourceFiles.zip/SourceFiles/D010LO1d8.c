
elem[7]+=
0
;
