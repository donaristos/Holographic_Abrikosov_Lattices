
elem[8]+=
0
;
