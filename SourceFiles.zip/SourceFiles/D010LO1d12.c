
elem[11]+=
0
;
