
elem[60]+=
0
;
