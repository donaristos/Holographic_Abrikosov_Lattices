
elem[253]+=
-4*q*h1(i,j,k)*pow(1 - rgrid[i],2)*Qr2(i,j,k)*D[-1 + d001](i,j,k,i1,j1,k1)
;
