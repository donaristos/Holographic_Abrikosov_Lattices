
elem[5]+=
0
;
