
elem[27]+=
0
;
