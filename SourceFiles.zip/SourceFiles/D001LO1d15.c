
elem[14]+=
0
;
