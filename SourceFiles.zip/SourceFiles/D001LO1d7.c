
elem[6]+=
0
;
